<?php return array('dependencies' => array(), 'version' => 'ca740a60dddf22a4b461');
